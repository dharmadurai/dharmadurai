const store = [];
let noTodo = 0;

class TodoService {
	find(params) {
		return Promise.resolve({ data: store });
	}
  
	get(id, params) {
		const idx = store.findIndex(obj => obj.id === id);
		return Promise.resolve(store[idx] || null);
	}

	create(data, params) {
		data.id = ++noTodo;
		store.push(data);
		return Promise.resolve(data);
	}

	update(id, data, params) {
		const idx = store.findIndex(obj => obj.id === id);
		store[idx] = data;
		return Promise.resolve(data || null);
	}

	patch(id, data, params) {
		const idx = store.findIndex(obj => obj.id === id);
		store[idx] = data;
		return Promise.resolve(data || null);
	}

	remove(id, params) {
		const idx = store.findIndex(obj => obj.id === id);
		store.splice(idx, 1);
		
		return Promise.resolve(null);
	}
  }
  
  module.exports = function (app) {
	  app.use('/object/todo', new TodoService());
  };
  