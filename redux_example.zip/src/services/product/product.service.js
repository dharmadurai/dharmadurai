class ProdcutService {
  find(params) {
      return Promise.resolve([
          {
              title: 'Ice cream'
          },
          {
              title: 'White forest'
          },
      ]);
  }

  get(id, params) {}
  create(data, params) {}
  update(id, data, params) {}
  patch(id, data, params) {}
  remove(id, params) {}
}

module.exports = function (app) {
    app.use('/object/product', new ProdcutService());
};
