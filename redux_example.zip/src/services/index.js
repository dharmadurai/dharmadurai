// eslint-disable-next-line no-unused-vars
const Product = require('./product/product.service');
const Todo = require('./todo/todo.service');

module.exports = function (app) {
    app.configure(Product);
    app.configure(Todo);
};
