// eslint-disable-next-line no-unused-vars
const express = require('@feathersjs/express');
const router = new express.Router();

const product = require('./product.js');
const home = require('./home.js');

module.exports = function (app) {
    app.use(function(req, _res, next) {
        req.pageTemplate = 'common/page';
        next();
    });

    app.use('/', router);

    router.get('/', home);
    router.get('/product', product);
};
