module.exports = function(req, res) {
    res.render(req.pageTemplate, {
        title: 'Products',
        pageIdent: 'product',
        param1: '',
        param2: ''
    });
};
