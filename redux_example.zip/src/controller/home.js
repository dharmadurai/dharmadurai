module.exports = function(req, res) {
    res.render(req.pageTemplate, {
        title: 'Home',
        pageIdent: 'home',
        param1: '',
        param2: ''
    });
};
