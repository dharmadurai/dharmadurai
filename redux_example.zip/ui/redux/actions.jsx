import { ADD_TODO, FETCH_TODO } from './actionTypes.jsx';
import app from '../app.jsx';

export const fetchTodo = todos => ({
	type: FETCH_TODO,
	todos
});

export const addTodo = content => {
	return dispatch => {
		return app.service('/object/todo').create({ content })
			.then((apiRes) => {
				dispatch(reloadTodo());
			})
	}
};

export const reloadTodo = () => {
	return dispatch => {
		return app.service('/object/todo').find()
			.then((apiRes) => {
				dispatch(fetchTodo(apiRes.data));
			})
	}
};
