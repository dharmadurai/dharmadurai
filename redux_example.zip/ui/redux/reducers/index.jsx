import { combineReducers } from 'redux';
import todos from './todos.jsx';

export default combineReducers({ todos });
