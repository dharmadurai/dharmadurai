import { ADD_TODO, FETCH_TODO } from '../actionTypes.jsx';

const initialState = {
    data: {

    }
};

export default function(state = initialState, action) {
    switch (action.type) {
        case ADD_TODO: {
            const { id, content } = action.payload;
            return {
                ...state,
                data: {
                    ...state.data,
                    [id]: {
                        id: id,
                        content: content
                    }
                }
            };
        }
        case FETCH_TODO: {
            const newData = {};
            action.todos.forEach(obj => {
                newData[obj.id] = obj;
            });

            return {
                ...state,
                data: newData
            }
        }
        default: {
            return state;
        }
    }
}
