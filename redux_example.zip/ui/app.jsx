import React, { Component } from "react";
import ReactDOM from "react-dom";
import io from 'socket.io-client';
import feathers from '@feathersjs/feathers';
import socketio from '@feathersjs/socketio-client';

import TodoApp from './todo/todoapp.jsx';

class App {
    constructor() {
        this._feathers = null;
    }

    init () {
        this._initFeathers();
        this._renderPage();
    }

    service(apiPath) {
        return this._feathers.service(apiPath);
    }

    _renderPage() {
        ReactDOM.render(
            <TodoApp />,
            document.getElementById('root')
        );
    }

    _initFeathers() {
        const socket = io('//');
        this._feathers = feathers();

        this._feathers.configure(socketio(socket));
    }
}

export default new App();
