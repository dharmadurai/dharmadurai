import app from './app.jsx';
app.init();
