import React, { Component } from 'react';
import { connect } from 'react-redux';

import { reloadTodo } from '../redux/actions.jsx';

class TodoList extends Component {
	componentDidMount() {
		const { dispatch } = this.props
		dispatch(reloadTodo());
	}

	render() {
		const { items } = this.props;

		return (
			<div className="todolist">
				{items.map((item) =>
					<div className="item" key={item.id}>
						{item.completed ? '[x]' : '[ ]'} {item.id} - {item.content}
					</div>
				)}
			</div>
		);
	}
}

export default connect((state) => {
	const { data } = state.todos;
	const items = Object.keys(data).map(key => data[key]);
	return { items };
})(TodoList);
