import React, { Component } from 'react';
import { connect } from 'react-redux';
import { addTodo } from '../redux/actions.jsx';

class AddTodo extends Component {
	_onAdd(ev) {
		console.log('Add item ', ev);
		this.props.addTodo('Demo input');
	}

	render() {
		return (
			<div className="addto" onClick={this._onAdd.bind(this)}>
				Add todo
			</div>
		);
	}
}

export default connect(null, { addTodo })(AddTodo);
