import React, { Component } from 'react';
import { Provider } from 'react-redux';

import TodoList from './todolist.jsx';
import AddTodo from './addtodo.jsx';
import configureStore from '../redux/store.jsx';

const store = configureStore();

class TodoApp extends Component {
	render() {
		return (
			<Provider store={store}>
				<div className="todoapp">
					<TodoList />
					<AddTodo />
				</div>
			</Provider>
		);
	}
}

export default TodoApp;
